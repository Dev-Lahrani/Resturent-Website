import { useState, createContext, useContext } from 'react';

type Page = 'home' | 'menu' | 'reservations' | 'about' | 'contact' | 'login' | 'signup' | 'cart' | 'profile';

interface RouterContextType {
  currentPage: Page;
  navigate: (page: Page) => void;
  isLoggedIn: boolean;
  setIsLoggedIn: (value: boolean) => void;
  user: { name: string; email: string } | null;
  setUser: (user: { name: string; email: string } | null) => void;
}

const RouterContext = createContext<RouterContextType | undefined>(undefined);

export function RouterProvider({ children }: { children: React.ReactNode }) {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);

  const navigate = (page: Page) => {
    setCurrentPage(page);
  };

  return (
    <RouterContext.Provider value={{
      currentPage,
      navigate,
      isLoggedIn,
      setIsLoggedIn,
      user,
      setUser
    }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter() {
  const context = useContext(RouterContext);
  if (context === undefined) {
    throw new Error('useRouter must be used within a RouterProvider');
  }
  return context;
}