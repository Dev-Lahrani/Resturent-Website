import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { AnimationWrapper } from "./AnimationWrapper";
import { ShoppingCart, Plus } from "lucide-react";

const featuredDishes = [
  {
    name: "Butter Chicken",
    description: "Tender chicken in a rich, creamy tomato-based sauce with aromatic spices",
    price: "$18.99",
    image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXR0ZXIlMjBjaGlja2VuJTIwY3VycnklMjBpbmRpYW58ZW58MXx8fHwxNzU3MDY4OTI4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    popular: true
  },
  {
    name: "Chicken Biryani",
    description: "Fragrant basmati rice layered with spiced chicken and fresh herbs",
    price: "$16.99",
    image: "https://images.unsplash.com/photo-1599043513900-ed6fe01d3833?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYmlyeWFuaSUyMHJpY2UlMjBkaXNofGVufDF8fHx8MTc1NzA2ODkyOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    popular: true
  },
  {
    name: "Tandoori Chicken",
    description: "Marinated chicken grilled in our traditional tandoor oven",
    price: "$15.99",
    image: "https://images.unsplash.com/photo-1627799370307-9b2a689bb94f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YW5kb29yaSUyMGNoaWNrZW4lMjBncmlsbGVkfGVufDF8fHx8MTc1NzA2ODkyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    popular: false
  },
  {
    name: "Mutton Curry",
    description: "Slow-cooked lamb in a rich blend of traditional spices",
    price: "$22.99",
    image: "https://images.unsplash.com/photo-1659716307017-dc91342ec2b8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXR0b24lMjBjdXJyeSUyMGxhbWJ8ZW58MXx8fHwxNzU3MDY4OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    popular: false
  }
];

export function FeaturedDishes() {
  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimationWrapper animation="fadeInUp">
          <div className="text-center mb-12">
            <h2 className="text-red-600 dark:text-red-400 mb-4">Our Signature Dishes</h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Discover our most popular non-vegetarian dishes, crafted with authentic spices and fresh ingredients
            </p>
          </div>
        </AnimationWrapper>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredDishes.map((dish, index) => (
            <AnimationWrapper key={index} animation="fadeInUp" delay={index * 100}>
              <Card className="overflow-hidden hover:shadow-xl dark:hover:shadow-2xl transition-all duration-300 group bg-white dark:bg-gray-800 border-0 shadow-md">
                <div className="relative">
                  <ImageWithFallback
                    src={dish.image}
                    alt={dish.name}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {dish.popular && (
                    <Badge className="absolute top-3 right-3 bg-red-600 dark:bg-red-500 text-white border-0">
                      Popular
                    </Badge>
                  )}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
                    <Button
                      size="sm"
                      className="bg-white/90 text-gray-900 hover:bg-white transform scale-90 group-hover:scale-100 transition-transform duration-300"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Add to Cart
                    </Button>
                  </div>
                </div>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-gray-900 dark:text-gray-100">{dish.name}</h3>
                    <span className="text-red-600 dark:text-red-400 font-semibold">{dish.price}</span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed mb-4">
                    {dish.description}
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="w-full group-hover:bg-red-600 group-hover:text-white group-hover:border-red-600 dark:group-hover:bg-red-500 transition-colors duration-300"
                  >
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Order Now
                  </Button>
                </CardContent>
              </Card>
            </AnimationWrapper>
          ))}
        </div>
      </div>
    </section>
  );
}