import { MenuSection } from '../MenuSection';
import { FeaturedDishes } from '../FeaturedDishes';
import { AnimationWrapper } from '../AnimationWrapper';

export function MenuPage() {
  return (
    <div className="bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-red-600 to-orange-600 dark:from-red-700 dark:to-orange-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp">
            <div className="text-center">
              <h1 className="text-white mb-4">Our Menu</h1>
              <p className="text-xl text-red-100 max-w-2xl mx-auto">
                Discover our extensive collection of authentic non-vegetarian dishes crafted with love and traditional spices
              </p>
            </div>
          </AnimationWrapper>
        </div>
      </section>

      <AnimationWrapper animation="fadeInUp" delay={200}>
        <FeaturedDishes />
      </AnimationWrapper>
      
      <AnimationWrapper animation="fadeInUp" delay={400}>
        <MenuSection />
      </AnimationWrapper>
    </div>
  );
}