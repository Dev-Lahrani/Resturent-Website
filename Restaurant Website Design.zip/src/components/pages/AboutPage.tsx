import { About } from '../About';
import { AnimationWrapper } from '../AnimationWrapper';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function AboutPage() {
  return (
    <div className="bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-red-600 to-orange-600 dark:from-red-700 dark:to-orange-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp">
            <div className="text-center">
              <h1 className="text-white mb-4">About Spice Kingdom</h1>
              <p className="text-xl text-red-100 max-w-2xl mx-auto">
                A journey of authentic flavors, traditional recipes, and culinary excellence spanning over two decades
              </p>
            </div>
          </AnimationWrapper>
        </div>
      </section>

      <AnimationWrapper animation="fadeInUp" delay={200}>
        <About />
      </AnimationWrapper>

      {/* Our Story Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp">
            <div className="text-center mb-12">
              <h2 className="text-gray-900 dark:text-gray-100 mb-4">Our Story</h2>
              <p className="text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
                From humble beginnings to becoming a culinary landmark
              </p>
            </div>
          </AnimationWrapper>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimationWrapper animation="slideInLeft" delay={300}>
              <div className="space-y-6">
                <div>
                  <h3 className="text-gray-900 dark:text-gray-100 mb-3">The Beginning (1999)</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Spice Kingdom was born from a dream to share authentic Indian non-vegetarian cuisine with the world. 
                    Our founder, Chef Rajesh Kumar, started with a small kitchen and a passion for traditional recipes 
                    passed down through generations.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-gray-900 dark:text-gray-100 mb-3">Growth & Recognition (2005-2015)</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Word spread about our exceptional butter chicken and biryanis. We expanded our menu, perfected our 
                    tandoor techniques, and became a favorite among food enthusiasts. Awards and recognition followed, 
                    but our commitment to quality never wavered.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-gray-900 dark:text-gray-100 mb-3">Today & Tomorrow</h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Today, Spice Kingdom is more than a restaurant – it's a destination for authentic flavors. 
                    We continue to innovate while honoring traditional cooking methods, ensuring every dish tells 
                    a story of heritage and passion.
                  </p>
                </div>
              </div>
            </AnimationWrapper>

            <AnimationWrapper animation="slideInRight" delay={500}>
              <div className="relative">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVmJTIwY29va2luZyUyMGluZGlhbiUyMGZvb2R8ZW58MXx8fHwxNzU3MDY4OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Chef cooking traditional Indian food"
                  className="w-full h-[400px] object-cover rounded-lg shadow-lg"
                />
              </div>
            </AnimationWrapper>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp">
            <div className="text-center mb-12">
              <h2 className="text-gray-900 dark:text-gray-100 mb-4">Our Values</h2>
              <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                The principles that guide everything we do
              </p>
            </div>
          </AnimationWrapper>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <AnimationWrapper animation="fadeInUp" delay={200}>
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-red-100 dark:bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🌶️</span>
                </div>
                <h3 className="text-gray-900 dark:text-gray-100 mb-3">Authentic Flavors</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Every spice, every recipe stays true to traditional Indian cooking methods and flavors.
                </p>
              </div>
            </AnimationWrapper>

            <AnimationWrapper animation="fadeInUp" delay={400}>
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🥘</span>
                </div>
                <h3 className="text-gray-900 dark:text-gray-100 mb-3">Fresh Ingredients</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  We source the finest, freshest ingredients daily to ensure exceptional quality in every dish.
                </p>
              </div>
            </AnimationWrapper>

            <AnimationWrapper animation="fadeInUp" delay={600}>
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-yellow-100 dark:bg-yellow-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">❤️</span>
                </div>
                <h3 className="text-gray-900 dark:text-gray-100 mb-3">Passionate Service</h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Our team is passionate about food and committed to providing exceptional dining experiences.
                </p>
              </div>
            </AnimationWrapper>
          </div>
        </div>
      </section>
    </div>
  );
}