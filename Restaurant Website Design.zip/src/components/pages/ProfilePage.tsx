import { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Separator } from '../ui/separator';
import { User, MapPin, Phone, Mail, Calendar, ShoppingBag, Star } from 'lucide-react';
import { useRouter } from '../Router';
import { AnimationWrapper } from '../AnimationWrapper';

export function ProfilePage() {
  const { user } = useRouter();
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '+1 (555) 123-4567',
    address: '123 Main Street, City, State 12345',
    birthdate: '1990-01-01'
  });

  const orderHistory = [
    {
      id: 'ORD-001',
      date: '2024-01-15',
      total: 45.99,
      status: 'Delivered',
      items: ['Butter Chicken', 'Chicken Biryani', 'Naan Bread']
    },
    {
      id: 'ORD-002',
      date: '2024-01-10',
      total: 32.50,
      status: 'Delivered',
      items: ['Mutton Rogan Josh', 'Basmati Rice']
    },
    {
      id: 'ORD-003',
      date: '2024-01-05',
      total: 67.80,
      status: 'Delivered',
      items: ['Fish Curry', 'Prawn Biryani', 'Chicken Tikka']
    }
  ];

  const reservationHistory = [
    {
      id: 'RES-001',
      date: '2024-01-20',
      time: '7:00 PM',
      guests: 4,
      status: 'Confirmed'
    },
    {
      id: 'RES-002',
      date: '2024-01-12',
      time: '6:30 PM',
      guests: 2,
      status: 'Completed'
    }
  ];

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate saving profile
    alert('Profile updated successfully!');
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md text-center">
          <CardContent className="pt-6">
            <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h2 className="text-gray-900 dark:text-gray-100 mb-2">Please Sign In</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              You need to be signed in to view your profile.
            </p>
            <Button className="bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600">
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <section className="bg-gradient-to-r from-red-600 to-orange-600 dark:from-red-700 dark:to-orange-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp">
            <div className="flex items-center space-x-6">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-white" />
              </div>
              <div>
                <h1 className="text-white mb-2">Welcome back, {user.name}!</h1>
                <p className="text-red-100">Manage your profile and view your order history</p>
              </div>
            </div>
          </AnimationWrapper>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp" delay={200}>
            <Tabs defaultValue="profile" className="w-full">
              <TabsList className="grid w-full grid-cols-3 max-w-md mx-auto mb-8">
                <TabsTrigger value="profile">Profile</TabsTrigger>
                <TabsTrigger value="orders">Orders</TabsTrigger>
                <TabsTrigger value="reservations">Reservations</TabsTrigger>
              </TabsList>

              {/* Profile Tab */}
              <TabsContent value="profile">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <AnimationWrapper animation="slideInLeft" delay={300}>
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-gray-900 dark:text-gray-100">
                          Personal Information
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <form onSubmit={handleSaveProfile} className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="name">Full Name</Label>
                            <Input
                              id="name"
                              value={profileData.name}
                              onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="email">Email</Label>
                            <Input
                              id="email"
                              type="email"
                              value={profileData.email}
                              onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="phone">Phone</Label>
                            <Input
                              id="phone"
                              value={profileData.phone}
                              onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="address">Address</Label>
                            <Input
                              id="address"
                              value={profileData.address}
                              onChange={(e) => setProfileData({ ...profileData, address: e.target.value })}
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="birthdate">Birth Date</Label>
                            <Input
                              id="birthdate"
                              type="date"
                              value={profileData.birthdate}
                              onChange={(e) => setProfileData({ ...profileData, birthdate: e.target.value })}
                            />
                          </div>
                          <Button 
                            type="submit" 
                            className="w-full bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600"
                          >
                            Save Changes
                          </Button>
                        </form>
                      </CardContent>
                    </Card>
                  </AnimationWrapper>

                  <AnimationWrapper animation="slideInRight" delay={500}>
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-gray-900 dark:text-gray-100">
                          Account Statistics
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center p-4 bg-red-50 dark:bg-red-900/10 rounded-lg">
                            <ShoppingBag className="w-8 h-8 text-red-600 dark:text-red-400 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">12</div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">Total Orders</div>
                          </div>
                          <div className="text-center p-4 bg-orange-50 dark:bg-orange-900/10 rounded-lg">
                            <Calendar className="w-8 h-8 text-orange-600 dark:text-orange-400 mx-auto mb-2" />
                            <div className="text-2xl font-bold text-gray-900 dark:text-gray-100">5</div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">Reservations</div>
                          </div>
                        </div>
                        
                        <Separator />
                        
                        <div>
                          <h4 className="text-gray-900 dark:text-gray-100 mb-3">Favorite Dishes</h4>
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Butter Chicken</span>
                              <Badge variant="secondary">5 orders</Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Chicken Biryani</span>
                              <Badge variant="secondary">3 orders</Badge>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm">Mutton Rogan Josh</span>
                              <Badge variant="secondary">2 orders</Badge>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </AnimationWrapper>
                </div>
              </TabsContent>

              {/* Orders Tab */}
              <TabsContent value="orders">
                <AnimationWrapper animation="fadeInUp" delay={300}>
                  <div className="space-y-4">
                    <h3 className="text-gray-900 dark:text-gray-100 mb-6">Order History</h3>
                    {orderHistory.map((order, index) => (
                      <Card key={order.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-4">
                            <div>
                              <h4 className="text-gray-900 dark:text-gray-100">Order {order.id}</h4>
                              <p className="text-gray-600 dark:text-gray-400 text-sm">{order.date}</p>
                            </div>
                            <div className="text-right">
                              <div className="text-red-600 dark:text-red-400 font-semibold">${order.total}</div>
                              <Badge variant="outline" className="text-green-600 border-green-600">
                                {order.status}
                              </Badge>
                            </div>
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm text-gray-600 dark:text-gray-400">Items:</p>
                            <p className="text-sm">{order.items.join(', ')}</p>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </AnimationWrapper>
              </TabsContent>

              {/* Reservations Tab */}
              <TabsContent value="reservations">
                <AnimationWrapper animation="fadeInUp" delay={300}>
                  <div className="space-y-4">
                    <h3 className="text-gray-900 dark:text-gray-100 mb-6">Reservation History</h3>
                    {reservationHistory.map((reservation, index) => (
                      <Card key={reservation.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="text-gray-900 dark:text-gray-100">Reservation {reservation.id}</h4>
                              <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mt-2">
                                <div className="flex items-center">
                                  <Calendar className="w-4 h-4 mr-1" />
                                  {reservation.date}
                                </div>
                                <div className="flex items-center">
                                  <Star className="w-4 h-4 mr-1" />
                                  {reservation.time}
                                </div>
                                <div className="flex items-center">
                                  <User className="w-4 h-4 mr-1" />
                                  {reservation.guests} guests
                                </div>
                              </div>
                            </div>
                            <Badge 
                              variant={reservation.status === 'Confirmed' ? 'default' : 'outline'}
                              className={reservation.status === 'Confirmed' ? 'bg-green-600' : ''}
                            >
                              {reservation.status}
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </AnimationWrapper>
              </TabsContent>
            </Tabs>
          </AnimationWrapper>
        </div>
      </section>
    </div>
  );
}