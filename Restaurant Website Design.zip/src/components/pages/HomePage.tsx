import { Hero } from '../Hero';
import { FeaturedDishes } from '../FeaturedDishes';
import { MenuSection } from '../MenuSection';
import { About } from '../About';
import { AnimationWrapper } from '../AnimationWrapper';

export function HomePage() {
  return (
    <div className="bg-background">
      <AnimationWrapper animation="fadeInUp">
        <Hero />
      </AnimationWrapper>
      
      <AnimationWrapper animation="fadeInUp" delay={200}>
        <FeaturedDishes />
      </AnimationWrapper>
      
      <AnimationWrapper animation="fadeInUp" delay={400}>
        <MenuSection />
      </AnimationWrapper>
      
      <AnimationWrapper animation="fadeInUp" delay={600}>
        <About />
      </AnimationWrapper>
    </div>
  );
}