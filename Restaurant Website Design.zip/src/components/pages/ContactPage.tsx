import { useState } from 'react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { MapPin, Phone, Mail, Clock, MessageCircle } from 'lucide-react';
import { AnimationWrapper } from '../AnimationWrapper';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    console.log('Form submitted:', formData);
    // Reset form
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    alert('Message sent! We\'ll get back to you soon.');
  };

  return (
    <div className="bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-red-600 to-orange-600 dark:from-red-700 dark:to-orange-700 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp">
            <div className="text-center">
              <h1 className="text-white mb-4">Contact Us</h1>
              <p className="text-xl text-red-100 max-w-2xl mx-auto">
                Get in touch with us for reservations, catering, or any questions about our cuisine
              </p>
            </div>
          </AnimationWrapper>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <AnimationWrapper animation="slideInLeft" delay={200}>
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-gray-900 dark:text-gray-100 flex items-center">
                    <MessageCircle className="w-5 h-5 mr-2 text-red-600" />
                    Send us a Message
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Full Name</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="subject">Subject</Label>
                        <Input
                          id="subject"
                          value={formData.subject}
                          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Message</Label>
                      <Textarea
                        id="message"
                        rows={6}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="Tell us how we can help you..."
                        required
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600"
                    >
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </AnimationWrapper>

            {/* Contact Information */}
            <AnimationWrapper animation="slideInRight" delay={400}>
              <div className="space-y-8">
                {/* Location */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-gray-100 flex items-center">
                      <MapPin className="w-5 h-5 mr-2 text-red-600" />
                      Visit Our Restaurant
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      123 Spice Street<br />
                      Flavor District, NY 10001<br />
                      United States
                    </p>
                    <div className="bg-gray-100 dark:bg-gray-800 rounded-lg h-48 flex items-center justify-center">
                      <p className="text-gray-500 dark:text-gray-400">Interactive Map Placeholder</p>
                    </div>
                  </CardContent>
                </Card>

                {/* Phone & Email */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardContent className="p-6 text-center">
                      <Phone className="w-8 h-8 text-red-600 mx-auto mb-3" />
                      <h3 className="text-gray-900 dark:text-gray-100 mb-2">Call Us</h3>
                      <p className="text-gray-600 dark:text-gray-400">+1 (555) 123-4567</p>
                      <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">Mon-Sun: 11AM-10PM</p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="p-6 text-center">
                      <Mail className="w-8 h-8 text-red-600 mx-auto mb-3" />
                      <h3 className="text-gray-900 dark:text-gray-100 mb-2">Email Us</h3>
                      <p className="text-gray-600 dark:text-gray-400">info@spicekingdom.com</p>
                      <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">We reply within 24hrs</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Hours */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-gray-100 flex items-center">
                      <Clock className="w-5 h-5 mr-2 text-red-600" />
                      Opening Hours
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                        <span className="text-gray-600 dark:text-gray-400">Monday - Thursday</span>
                        <span className="font-medium">11:00 AM - 10:00 PM</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
                        <span className="text-gray-600 dark:text-gray-400">Friday - Saturday</span>
                        <span className="font-medium">11:00 AM - 11:00 PM</span>
                      </div>
                      <div className="flex justify-between items-center py-2">
                        <span className="text-gray-600 dark:text-gray-400">Sunday</span>
                        <span className="font-medium">12:00 PM - 9:00 PM</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Additional Services */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-gray-100">Services</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div className="p-4 bg-red-50 dark:bg-red-900/10 rounded-lg">
                        <div className="text-2xl mb-2">🍽️</div>
                        <p className="text-sm font-medium">Dine-In</p>
                      </div>
                      <div className="p-4 bg-orange-50 dark:bg-orange-900/10 rounded-lg">
                        <div className="text-2xl mb-2">🚚</div>
                        <p className="text-sm font-medium">Delivery</p>
                      </div>
                      <div className="p-4 bg-yellow-50 dark:bg-yellow-900/10 rounded-lg">
                        <div className="text-2xl mb-2">📦</div>
                        <p className="text-sm font-medium">Takeout</p>
                      </div>
                      <div className="p-4 bg-green-50 dark:bg-green-900/10 rounded-lg">
                        <div className="text-2xl mb-2">🎉</div>
                        <p className="text-sm font-medium">Catering</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </AnimationWrapper>
          </div>
        </div>
      </section>
    </div>
  );
}