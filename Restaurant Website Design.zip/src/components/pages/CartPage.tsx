import { useState } from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Separator } from '../ui/separator';
import { Badge } from '../ui/badge';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import { AnimationWrapper } from '../AnimationWrapper';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  spicy: string;
  description: string;
}

export function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: '1',
      name: 'Butter Chicken',
      price: 18.99,
      quantity: 2,
      spicy: 'mild',
      description: 'Creamy tomato-based curry with tender chicken'
    },
    {
      id: '2',
      name: 'Chicken Biryani',
      price: 16.99,
      quantity: 1,
      spicy: 'mild',
      description: 'Fragrant rice with spiced chicken'
    },
    {
      id: '3',
      name: 'Mutton Rogan Josh',
      price: 22.99,
      quantity: 1,
      spicy: 'medium',
      description: 'Kashmiri lamb curry with aromatic spices'
    }
  ]);

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity === 0) {
      setCartItems(items => items.filter(item => item.id !== id));
    } else {
      setCartItems(items =>
        items.map(item =>
          item.id === id ? { ...item, quantity: newQuantity } : item
        )
      );
    }
  };

  const removeItem = (id: string) => {
    setCartItems(items => items.filter(item => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.08; // 8% tax
  const delivery = subtotal > 50 ? 0 : 4.99;
  const total = subtotal + tax + delivery;

  const spicyColors = {
    mild: "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400",
    medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400",
    hot: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
  };

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <AnimationWrapper animation="fadeInUp">
              <div className="text-center">
                <div className="w-24 h-24 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-6">
                  <ShoppingBag className="w-12 h-12 text-gray-400" />
                </div>
                <h1 className="text-gray-900 dark:text-gray-100 mb-4">Your cart is empty</h1>
                <p className="text-gray-600 dark:text-gray-400 mb-8">
                  Looks like you haven't added any delicious dishes to your cart yet.
                </p>
                <Button className="bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600">
                  Browse Menu
                </Button>
              </div>
            </AnimationWrapper>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <section className="py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimationWrapper animation="fadeInUp">
            <div className="mb-8">
              <h1 className="text-gray-900 dark:text-gray-100 mb-2">Your Cart</h1>
              <p className="text-gray-600 dark:text-gray-400">
                {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} in your cart
              </p>
            </div>
          </AnimationWrapper>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              {cartItems.map((item, index) => (
                <AnimationWrapper key={item.id} animation="slideInLeft" delay={index * 100}>
                  <Card>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="text-gray-900 dark:text-gray-100">{item.name}</h3>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeItem(item.id)}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                            {item.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <Badge className={spicyColors[item.spicy as keyof typeof spicyColors]}>
                                {item.spicy}
                              </Badge>
                              <span className="text-red-600 dark:text-red-400">${item.price}</span>
                            </div>
                            <div className="flex items-center space-x-3">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                className="w-8 h-8 p-0"
                              >
                                <Minus className="w-4 h-4" />
                              </Button>
                              <span className="w-8 text-center">{item.quantity}</span>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                className="w-8 h-8 p-0"
                              >
                                <Plus className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </AnimationWrapper>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <AnimationWrapper animation="slideInRight" delay={200}>
                <Card className="sticky top-8">
                  <CardHeader>
                    <CardTitle className="text-gray-900 dark:text-gray-100">Order Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Subtotal</span>
                        <span>${subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Tax</span>
                        <span>${tax.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Delivery</span>
                        <span>
                          {delivery === 0 ? (
                            <span className="text-green-600 dark:text-green-400">Free</span>
                          ) : (
                            `$${delivery.toFixed(2)}`
                          )}
                        </span>
                      </div>
                      {delivery > 0 && (
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Free delivery on orders over $50
                        </p>
                      )}
                    </div>

                    <Separator />

                    <div className="flex justify-between">
                      <span className="font-semibold">Total</span>
                      <span className="font-semibold">${total.toFixed(2)}</span>
                    </div>

                    <div className="space-y-3 pt-4">
                      <Button className="w-full bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600">
                        Proceed to Checkout
                      </Button>
                      <Button variant="outline" className="w-full">
                        Continue Shopping
                      </Button>
                    </div>

                    <div className="pt-4 border-t">
                      <h4 className="text-sm font-medium mb-2">Delivery Information</h4>
                      <div className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                        <p>• Estimated delivery: 30-45 minutes</p>
                        <p>• Delivery area: 5 mile radius</p>
                        <p>• Contact-free delivery available</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </AnimationWrapper>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}