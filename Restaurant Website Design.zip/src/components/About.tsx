import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Card, CardContent } from "./ui/card";
import { Clock, Users, Award, ChefHat } from "lucide-react";
import { AnimationWrapper } from "./AnimationWrapper";

export function About() {
  const features = [
    {
      icon: <ChefHat className="h-8 w-8 text-red-600" />,
      title: "Expert Chefs",
      description: "Our master chefs bring decades of experience in authentic Indian non-veg cuisine"
    },
    {
      icon: <Award className="h-8 w-8 text-red-600" />,
      title: "Premium Quality",
      description: "We source only the finest ingredients and freshest meats for our dishes"
    },
    {
      icon: <Users className="h-8 w-8 text-red-600" />,
      title: "Family Tradition",
      description: "Three generations of culinary expertise passed down through our family"
    },
    {
      icon: <Clock className="h-8 w-8 text-red-600" />,
      title: "Fresh Daily",
      description: "All our curries and marinades are prepared fresh daily using traditional methods"
    }
  ];

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <AnimationWrapper animation="slideInLeft" delay={200}>
            <div>
              <h2 className="text-gray-900 dark:text-gray-100 mb-6">About Spice Kingdom</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
                For over 25 years, Spice Kingdom has been serving the finest non-vegetarian Indian cuisine 
                in the heart of the city. Our journey began with a simple mission: to bring authentic, 
                home-style flavors to food lovers who appreciate the art of traditional cooking.
              </p>
              <p className="text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
                From our signature butter chicken to our aromatic biryanis, every dish is crafted with 
                passion, using time-honored recipes and the freshest ingredients. We take pride in 
                our tandoor cooking and slow-simmered curries that have made us a favorite among 
                meat lovers across the region.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                {features.map((feature, index) => (
                  <AnimationWrapper key={index} animation="scaleIn" delay={400 + index * 100}>
                    <Card className="border-none shadow-md dark:shadow-lg bg-white dark:bg-gray-800 hover:shadow-lg dark:hover:shadow-xl transition-shadow duration-300">
                      <CardContent className="p-6 text-center">
                        <div className="flex justify-center mb-3">
                          {feature.icon}
                        </div>
                        <h4 className="text-gray-900 dark:text-gray-100 mb-2">{feature.title}</h4>
                        <p className="text-gray-600 dark:text-gray-400 text-sm leading-relaxed">{feature.description}</p>
                      </CardContent>
                    </Card>
                  </AnimationWrapper>
                ))}
              </div>
            </div>
          </AnimationWrapper>
          
          <AnimationWrapper animation="slideInRight" delay={400}>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1667388968964-4aa652df0a9b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXN0YXVyYW50JTIwaW50ZXJpb3IlMjBkaW5pbmd8ZW58MXx8fHwxNzU3MDEwNDM3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Restaurant interior"
                className="w-full h-[500px] object-cover rounded-lg shadow-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg"></div>
            </div>
          </AnimationWrapper>
        </div>
      </div>
    </section>
  );
}