import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { AnimationWrapper } from "./AnimationWrapper";
import { Plus, ShoppingCart } from "lucide-react";

const menuData = {
  chicken: [
    { name: "Butter Chicken", description: "Creamy tomato-based curry with tender chicken", price: "$18.99", spicy: "mild" },
    { name: "Chicken Tikka Masala", description: "Grilled chicken in rich, creamy sauce", price: "$17.99", spicy: "mild" },
    { name: "Chicken Vindaloo", description: "Spicy Goan curry with potatoes", price: "$19.99", spicy: "hot" },
    { name: "Chicken Korma", description: "Mild curry with coconut and cashews", price: "$16.99", spicy: "mild" },
    { name: "Chicken Jalfrezi", description: "Stir-fried with peppers and onions", price: "$17.99", spicy: "medium" },
    { name: "Chicken Madras", description: "South Indian style spicy curry", price: "$18.99", spicy: "hot" }
  ],
  mutton: [
    { name: "Mutton Rogan Josh", description: "Kashmiri lamb curry with aromatic spices", price: "$22.99", spicy: "medium" },
    { name: "Mutton Biryani", description: "Fragrant rice with tender lamb pieces", price: "$24.99", spicy: "mild" },
    { name: "Keema Curry", description: "Spiced ground lamb with peas", price: "$20.99", spicy: "medium" },
    { name: "Mutton Korma", description: "Mild creamy curry with tender lamb", price: "$23.99", spicy: "mild" },
    { name: "Lamb Vindaloo", description: "Fiery Goan curry with tender lamb", price: "$25.99", spicy: "hot" }
  ],
  seafood: [
    { name: "Fish Curry", description: "Fresh fish in coconut-based curry", price: "$21.99", spicy: "medium" },
    { name: "Prawn Masala", description: "Jumbo prawns in spiced tomato gravy", price: "$24.99", spicy: "medium" },
    { name: "Fish Tikka", description: "Marinated fish grilled in tandoor", price: "$19.99", spicy: "mild" },
    { name: "Goan Fish Curry", description: "Coconut milk based curry with kokum", price: "$22.99", spicy: "mild" },
    { name: "Prawn Biryani", description: "Aromatic rice with succulent prawns", price: "$26.99", spicy: "mild" }
  ],
  biryani: [
    { name: "Chicken Biryani", description: "Classic Hyderabadi style with chicken", price: "$16.99", spicy: "mild" },
    { name: "Mutton Biryani", description: "Royal biryani with tender lamb", price: "$24.99", spicy: "mild" },
    { name: "Prawn Biryani", description: "Coastal style with fresh prawns", price: "$26.99", spicy: "mild" },
    { name: "Egg Biryani", description: "Fragrant rice with boiled eggs", price: "$14.99", spicy: "mild" },
    { name: "Mixed Biryani", description: "Combination of chicken and mutton", price: "$21.99", spicy: "mild" }
  ]
};

const spicyColors = {
  mild: "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-400",
  medium: "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-400",
  hot: "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-400"
};

export function MenuSection() {
  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimationWrapper animation="fadeInUp">
          <div className="text-center mb-12">
            <h2 className="text-gray-900 dark:text-gray-100 mb-4">Our Complete Menu</h2>
            <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              Explore our extensive collection of authentic non-vegetarian dishes
            </p>
          </div>
        </AnimationWrapper>

        <AnimationWrapper animation="fadeInUp" delay={200}>
          <Tabs defaultValue="chicken" className="w-full">
            <TabsList className="grid w-full grid-cols-4 max-w-2xl mx-auto mb-8">
              <TabsTrigger value="chicken">Chicken</TabsTrigger>
              <TabsTrigger value="mutton">Mutton & Lamb</TabsTrigger>
              <TabsTrigger value="seafood">Seafood</TabsTrigger>
              <TabsTrigger value="biryani">Biryani</TabsTrigger>
            </TabsList>

            {Object.entries(menuData).map(([category, dishes]) => (
              <TabsContent key={category} value={category}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {dishes.map((dish, index) => (
                    <AnimationWrapper key={index} animation="fadeInUp" delay={index * 50}>
                      <Card className="hover:shadow-lg dark:hover:shadow-xl transition-all duration-300 group bg-white dark:bg-gray-800 border-0 shadow-md">
                        <CardContent className="p-6">
                          <div className="flex justify-between items-start mb-3">
                            <h3 className="text-gray-900 dark:text-gray-100 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">
                              {dish.name}
                            </h3>
                            <div className="flex items-center gap-2">
                              <Badge className={spicyColors[dish.spicy as keyof typeof spicyColors]}>
                                {dish.spicy}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 leading-relaxed">
                            {dish.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <span className="text-red-600 dark:text-red-400 font-semibold text-lg">
                              {dish.price}
                            </span>
                            <Button
                              size="sm"
                              className="bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              Add
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </AnimationWrapper>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </AnimationWrapper>
      </div>
    </section>
  );
}