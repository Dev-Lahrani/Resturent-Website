import { MapPin, Phone, Clock, Mail, Facebook, Instagram, Twitter } from "lucide-react";
import { useRouter } from "./Router";
import { AnimationWrapper } from "./AnimationWrapper";

export function Footer() {
  const { navigate } = useRouter();

  return (
    <footer className="bg-gray-900 dark:bg-gray-950 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <AnimationWrapper animation="fadeInUp" delay={100}>
            <div>
              <h3 className="text-red-400 dark:text-red-300 mb-4">Spice Kingdom</h3>
              <p className="text-gray-300 dark:text-gray-400 mb-4">
                Authentic non-vegetarian Indian cuisine served with passion and tradition for over 25 years.
              </p>
              <div className="flex space-x-4">
                <Facebook className="h-5 w-5 text-gray-400 hover:text-red-400 dark:hover:text-red-300 cursor-pointer transition-colors" />
                <Instagram className="h-5 w-5 text-gray-400 hover:text-red-400 dark:hover:text-red-300 cursor-pointer transition-colors" />
                <Twitter className="h-5 w-5 text-gray-400 hover:text-red-400 dark:hover:text-red-300 cursor-pointer transition-colors" />
              </div>
            </div>
          </AnimationWrapper>

          <AnimationWrapper animation="fadeInUp" delay={200}>
            <div>
              <h4 className="mb-4 text-white">Contact Info</h4>
              <div className="space-y-3 text-gray-300 dark:text-gray-400">
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 mr-3 text-red-400 dark:text-red-300" />
                  <span>123 Spice Street, Flavor District, NY 10001</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-5 w-5 mr-3 text-red-400 dark:text-red-300" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-5 w-5 mr-3 text-red-400 dark:text-red-300" />
                  <span>info@spicekingdom.com</span>
                </div>
              </div>
            </div>
          </AnimationWrapper>

          <AnimationWrapper animation="fadeInUp" delay={300}>
            <div>
              <h4 className="mb-4 text-white">Opening Hours</h4>
              <div className="space-y-2 text-gray-300 dark:text-gray-400">
                <div className="flex justify-between">
                  <span>Monday - Thursday</span>
                  <span>11 AM - 10 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Friday - Saturday</span>
                  <span>11 AM - 11 PM</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span>12 PM - 9 PM</span>
                </div>
              </div>
            </div>
          </AnimationWrapper>

          <AnimationWrapper animation="fadeInUp" delay={400}>
            <div>
              <h4 className="mb-4 text-white">Quick Links</h4>
              <div className="space-y-2">
                <button 
                  onClick={() => navigate('home')} 
                  className="block text-gray-300 dark:text-gray-400 hover:text-red-400 dark:hover:text-red-300 transition-colors"
                >
                  Home
                </button>
                <button 
                  onClick={() => navigate('menu')} 
                  className="block text-gray-300 dark:text-gray-400 hover:text-red-400 dark:hover:text-red-300 transition-colors"
                >
                  Menu
                </button>
                <button 
                  onClick={() => navigate('reservations')} 
                  className="block text-gray-300 dark:text-gray-400 hover:text-red-400 dark:hover:text-red-300 transition-colors"
                >
                  Reservations
                </button>
                <button 
                  onClick={() => navigate('about')} 
                  className="block text-gray-300 dark:text-gray-400 hover:text-red-400 dark:hover:text-red-300 transition-colors"
                >
                  About
                </button>
                <button 
                  onClick={() => navigate('contact')} 
                  className="block text-gray-300 dark:text-gray-400 hover:text-red-400 dark:hover:text-red-300 transition-colors"
                >
                  Contact
                </button>
              </div>
            </div>
          </AnimationWrapper>
        </div>

        <div className="border-t border-gray-700 dark:border-gray-800 mt-8 pt-8 text-center text-gray-400 dark:text-gray-500">
          <p>&copy; 2024 Spice Kingdom. All rights reserved. | Designed with passion for great food.</p>
        </div>
      </div>
    </footer>
  );
}