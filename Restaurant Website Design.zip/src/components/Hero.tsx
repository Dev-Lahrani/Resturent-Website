import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useRouter } from "./Router";
import { AnimationWrapper } from "./AnimationWrapper";

export function Hero() {
  const { navigate } = useRouter();

  return (
    <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1589778655375-3e622a9fc91c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBmb29kJTIwc3ByZWFkJTIwZmVhc3R8ZW58MXx8fHwxNzU3MDY4OTI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Indian food spread"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/60 dark:bg-black/70"></div>
      </div>
      
      <div className="relative z-10 text-center text-white max-w-6xl mx-auto px-4">
        <AnimationWrapper animation="fadeInUp" delay={300}>
          <h1 className="text-5xl md:text-7xl mb-6 tracking-tight text-white">
            Welcome to <span className="text-red-400 dark:text-red-300">Spice Kingdom</span>
          </h1>
        </AnimationWrapper>
        
        <AnimationWrapper animation="fadeInUp" delay={600}>
          <p className="text-xl md:text-2xl mb-10 text-gray-100 max-w-3xl mx-auto leading-relaxed">
            Experience the finest non-vegetarian cuisine with authentic flavors. 
            From succulent butter chicken to aromatic biryanis, we serve the best of Indian non-veg delicacies.
          </p>
        </AnimationWrapper>
        
        <AnimationWrapper animation="fadeInUp" delay={900}>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button 
              size="lg" 
              className="bg-red-600 hover:bg-red-700 dark:bg-red-500 dark:hover:bg-red-600 text-white px-10 py-4 text-lg"
              onClick={() => navigate('menu')}
            >
              View Our Menu
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-2 border-white text-white hover:bg-white hover:text-black dark:hover:bg-gray-100 dark:hover:text-gray-900 px-10 py-4 text-lg backdrop-blur-sm"
              onClick={() => navigate('reservations')}
            >
              Make Reservation
            </Button>
          </div>
        </AnimationWrapper>
        
        <AnimationWrapper animation="fadeInUp" delay={1200}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16 text-center">
            <div className="bg-white/10 dark:bg-gray-900/30 backdrop-blur-sm rounded-lg p-6">
              <div className="text-3xl mb-2">25+</div>
              <div className="text-gray-200">Years Experience</div>
            </div>
            <div className="bg-white/10 dark:bg-gray-900/30 backdrop-blur-sm rounded-lg p-6">
              <div className="text-3xl mb-2">50+</div>
              <div className="text-gray-200">Signature Dishes</div>
            </div>
            <div className="bg-white/10 dark:bg-gray-900/30 backdrop-blur-sm rounded-lg p-6">
              <div className="text-3xl mb-2">1000+</div>
              <div className="text-gray-200">Happy Customers</div>
            </div>
          </div>
        </AnimationWrapper>
      </div>
    </section>
  );
}